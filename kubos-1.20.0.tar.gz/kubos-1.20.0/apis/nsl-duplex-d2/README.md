# NSL EyeStar-D2 Duplex API

API for interacting with an NSL EyeStar-D2 Duplex Globalstar radio