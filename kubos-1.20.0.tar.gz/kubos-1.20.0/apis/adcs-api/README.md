# Common ADCS API

API which abstracts out common ADCS functionality.
It will be used by specific ADCS device APIs as needed.