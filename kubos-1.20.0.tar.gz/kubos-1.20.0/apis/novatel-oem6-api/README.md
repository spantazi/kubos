# NovAtel OEM6 API

API for interacting with a NovAtel OEM6 GNSS receiver.

Note: This API may also be compatible with the NovAtel OEM7