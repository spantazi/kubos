# Clyde Space 3rd Generation EPS API

API for interacting with a Clyde Space 3G EPS (STARBUCK-NANO)