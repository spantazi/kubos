# ISIS iOBC Supervisor API

API for interacting with and ISIS iOBC's supervisor chip