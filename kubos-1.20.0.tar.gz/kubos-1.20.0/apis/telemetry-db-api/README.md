# Kubos Telemetry Database API

API for interacting with a telemetry database.
Utilized by the Kubos telemetry DB service. 