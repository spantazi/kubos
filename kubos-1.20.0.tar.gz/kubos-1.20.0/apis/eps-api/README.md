# Common EPS API

This crate contains high level types and functions for use by other crates
implementing EPS APIs.