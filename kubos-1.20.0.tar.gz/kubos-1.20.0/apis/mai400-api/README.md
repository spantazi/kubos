# MAI-400 ADACS API

API for interacting with an Adcole Maryland Aerospace MAI-400