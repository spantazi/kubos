# Kubos System API

Helper API for performing various general system actions:

- Initialize system configuration information
- Lookup specific configuration values
- Read and write U-Boot environment variables