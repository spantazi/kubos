# ISIS iMTQ API

API for interacting with an ISIS iMTQ magnetorquer