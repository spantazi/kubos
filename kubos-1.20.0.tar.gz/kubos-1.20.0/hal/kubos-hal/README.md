# HAL Library for C in KubOS

This library provides abstractions for performing I2C operations in C