Contributing to KubOS
---

Before a pull request is merged, you must [sign our Contributor's License Agreement](https://www.clahub.com/agreements/kubostech/KubOS)
