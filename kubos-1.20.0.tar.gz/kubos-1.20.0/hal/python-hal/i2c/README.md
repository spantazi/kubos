# I2C library for Python in KubOS

This library provides abstractions for performing I2C operations in Python

Installation:

`$ python setup.py install`
