# UART TX with Kubos Linux

**NOTE: EXPERIMENTAL (Work in Progress)**

This is a demo program to test UART transmission. It will write an incrementing message "Test message nnn" every 5 seconds out of `/dev/ttyS3`.

This program should be paired with the UART RX demo program.