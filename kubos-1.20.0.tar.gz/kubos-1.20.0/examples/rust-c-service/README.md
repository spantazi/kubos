# Example Service Using Rust and C

This example service shows how a Rust-based service can be written to use a C-based
API.

The `extern-lib` directory contains the C code which will be used by the Rust
service in the `service` directory.