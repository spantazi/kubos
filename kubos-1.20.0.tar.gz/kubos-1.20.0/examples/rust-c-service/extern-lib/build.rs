fn main() {
    kubos_build_helper::build_module()
}
