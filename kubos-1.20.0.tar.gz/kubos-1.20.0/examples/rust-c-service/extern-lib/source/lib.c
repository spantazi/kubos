#include <stdio.h>

void init_device(void) {
    printf("Performing low level device init...\n");
}

void terminate_device(void) {
    printf("Performing low level device termination...\n");
}
