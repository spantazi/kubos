# Kubos Linux Example App

This is a simple "Hello World!" application built on top of the [Kubos Linux Platform](https://github.com/kubos/kubos-linux-build). 
    
# Resources

For more information about the SDK, see our docs:

- [Kubos Docs](http://docs.kubos.co)
- [Installing the Kubos SDK](http://docs.kubos.co/latest/sdk-installing.html)
- [Kubos SDK Cheatsheet](http://docs.kubos.co/latest/sdk-cheatsheet.html) 
- [Kubos CLI Command Reference](http://docs.kubos.co/latest/sdk-reference.html) 
- [Kubos Project Configuration](http://docs.kubos.co/latest/sdk-project-config.html)

    
    
