# Pumpkin MCU API Example Usage

This is a script to simply show how to exercise the different functionality within the mcu_api KubOS package for interaction with Pumpkin MCUs. Comments within the script contain additional explaination. 

Run:

`$ python example_mcu_api.py`

