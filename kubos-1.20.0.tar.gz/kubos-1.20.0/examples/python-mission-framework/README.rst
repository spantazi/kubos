Python Mission Application Framework
====================================

This script shows the basic layout a mission application written in Python will use in order
to be successfully registered and run using the Kubos mission applications service.