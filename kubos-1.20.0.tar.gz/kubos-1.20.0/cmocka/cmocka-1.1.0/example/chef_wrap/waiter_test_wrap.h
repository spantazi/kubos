
int __wrap_chef_cook(const char *order, char **dish_out);
