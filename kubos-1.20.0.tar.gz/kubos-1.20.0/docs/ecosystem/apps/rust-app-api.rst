Rust Applications API
=====================

|rust-api|

 .. |rust-api| raw:: html

    <a href="../../rust-docs/kubos_app/index.html" target="_blank">Rust Applications API</a>
