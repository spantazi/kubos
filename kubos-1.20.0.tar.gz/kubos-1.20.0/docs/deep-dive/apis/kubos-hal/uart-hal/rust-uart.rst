UART Using Rust
===============

Please refer to the |uart-api| crate documentation for implementation details

 .. |uart-api| raw:: html

    <a href="../../../../rust-docs/rust_uart/index.html" target="_blank">Rust UART API</a>
