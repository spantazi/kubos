ISIS Antenna Systems API
========================

This Rust crate provides an API for interacting with the
`ISIS Antenna Systems <https://www.isispace.nl/product-category/cubesat-products/cubesat-antenna-systems/>`__.

Please refer to the |api| crate documentation for implementation details

 .. |api| raw:: html

    <a href="../../../../rust-docs/isis_ants_api/index.html" target="_blank">AntS API</a>