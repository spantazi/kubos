Clyde Space 3G EPS API
======================

This Rust crate provides an API for interacting with the `Clyde Space STARBUCK-NANO EPS <https://www.aac-clyde.space/satellite-bits/eps>`__

Please refer to the |api| crate documentation for implementation details

 .. |api| raw:: html

    <a href="../../../rust-docs/clyde_3g_eps/index.html" target="_blank">3G EPS API</a>