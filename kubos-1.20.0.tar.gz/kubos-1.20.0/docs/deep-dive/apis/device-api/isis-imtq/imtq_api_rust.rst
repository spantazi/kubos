ISIS iMTQ API
=============

This Rust crate provides an API for interacting with the `ISIS iMTQ magnetorquer <https://www.isispace.nl/product/isis-magnetorquer-board/>`__.

Please refer to the |api| crate documentation for implementation details

 .. |api| raw:: html

    <a href="../../../../rust-docs/isis_imtq_api/index.html" target="_blank">iMTQ API</a>