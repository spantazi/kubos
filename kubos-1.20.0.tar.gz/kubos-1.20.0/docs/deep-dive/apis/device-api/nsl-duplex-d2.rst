NSL EyeStar-D2 API
==================

This Rust crate provides an API for interacting with the `NSL EyeStar-D2 Duplex Radio <https://www.nearspacelaunch.com/collections/eyestar-radiosolutions/products/radio>`__

Please refer to the |api| crate documentation for implementation details

 .. |api| raw:: html

    <a href="../../../rust-docs/nsl_duplex_d2/index.html" target="_blank">EyeStar-D2 API</a>