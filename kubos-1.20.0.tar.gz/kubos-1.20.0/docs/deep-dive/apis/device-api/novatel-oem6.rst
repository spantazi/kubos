NovAtel OEM6 API
================

This Rust crate provides an API for interacting with `NovAtel OEM6 High Precision GNSS Receivers <https://www.novatel.com/products/gnss-receivers/oem-receiver-boards/oem6-receivers/>`__

Please refer to the |api| crate documentation for implementation details

 .. |api| raw:: html

    <a href="../../../rust-docs/novatel_oem6_api/index.html" target="_blank">OEM6 API</a>