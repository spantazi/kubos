# CBOR Protocol Library

This library provides the ability to send and receive CBOR-based messages over UDP